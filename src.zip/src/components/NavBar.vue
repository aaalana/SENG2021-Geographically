<template>
  <nav>
    <v-toolbar app dark>
      <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
      <img alt="logo" src="../assets/mapLogo.png" height=30px>
      <v-toolbar-title class="headline text">
        <span style= "font-family:Quicksand" class="font-weight-regular">Geographically</span>
      </v-toolbar-title>
      <v-spacer></v-spacer>
        <span style= "font-family:Quicksand" class="font-weight-light subheading">Sign up / Login</span>
    </v-toolbar>
  </nav>
</template>

<script> 
export default {

}
</script>
